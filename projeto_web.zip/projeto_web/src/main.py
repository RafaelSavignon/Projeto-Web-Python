from src.pessoa import Pessoa


p1 = Pessoa("Fulano", 25)
p1.falar("Olá, pessoal!!!")

p2 = Pessoa("Sicrano", 21)
p2.falar("Olá, galerinha!!!")

p3 = Pessoa("Beltrano", 23)
p3.falar("Olá, turma!!!")