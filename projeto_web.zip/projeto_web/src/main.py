from typing import List
from src.administrativo import Administrativo
from src.funcionario import Funcionario
from src.professor import Professor


funcionarios: List[Funcionario] = []
funcionarios.append(Professor("Fulano", 152, "245"))
funcionarios.append(Administrativo("Sicrano", 21, "Compras"))
funcionarios.append(Professor("Beltrano", 23, "678"))
funcionarios.append(Administrativo("Fortrano", 25, "Finanças"))
funcionarios.append(Professor("Sicrano", 21, "789"))
funcionarios.append(Administrativo("Beltrano", 23, "Atendimento"))

for i in funcionarios:
    print(f"'{i.nome}' recebe '{i.calcular_salario()}'")