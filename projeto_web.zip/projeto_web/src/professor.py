from src.pessoa import Pessoa


class Professor(Pessoa):
    def __init__(self, nome, idade, siape):
        super().__init__(nome, idade)
        self.siape = siape