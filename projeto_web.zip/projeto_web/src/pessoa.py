class Pessoa:
    def __init__(self, nome, idade):
        self.nome = nome.upper()
        self.idade = idade
    
    def falar(self, mensagem):
        print(f"{self.nome} falou '{mensagem}'")