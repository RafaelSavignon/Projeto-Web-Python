from abc import abstractmethod
from src.pessoa import Pessoa


class Funcionario(Pessoa):
    def __init__(self, nome, idade):
        super().__init__(nome, idade)

    @abstractmethod
    def calcular_salario(self) -> float:
        pass